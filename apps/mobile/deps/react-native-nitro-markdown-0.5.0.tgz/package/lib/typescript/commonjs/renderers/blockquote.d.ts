import { type FC, type ReactNode } from "react";
import { type ViewStyle } from "react-native";
type BlockquoteProps = {
    children: ReactNode;
    style?: ViewStyle;
};
export declare const Blockquote: FC<BlockquoteProps>;
export {};
//# sourceMappingURL=blockquote.d.ts.map