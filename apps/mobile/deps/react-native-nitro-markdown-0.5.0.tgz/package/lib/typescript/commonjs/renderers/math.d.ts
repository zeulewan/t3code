import { type FC } from "react";
import { type ViewStyle } from "react-native";
type MathInlineProps = {
    content?: string;
    style?: ViewStyle;
};
export declare const MathInline: FC<MathInlineProps>;
type MathBlockProps = {
    content?: string;
    style?: ViewStyle;
};
export declare const MathBlock: FC<MathBlockProps>;
export {};
//# sourceMappingURL=math.d.ts.map