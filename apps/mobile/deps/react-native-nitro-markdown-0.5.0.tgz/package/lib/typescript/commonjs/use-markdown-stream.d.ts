import { createMarkdownSession } from "./MarkdownSession";
export type MarkdownSession = ReturnType<typeof createMarkdownSession>;
export declare function useMarkdownSession(): {
    getSession: () => import("./specs/MarkdownSession.nitro").MarkdownSession;
    isStreaming: boolean;
    setIsStreaming: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    stop: () => void;
    clear: () => void;
    setHighlight: (position: number) => void;
};
export declare function useStream(timestamps?: Record<number, number>): {
    isPlaying: boolean;
    setIsPlaying: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    sync: (currentTimeMs: number) => void;
    getSession: () => import("./specs/MarkdownSession.nitro").MarkdownSession;
    isStreaming: boolean;
    setIsStreaming: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    stop: () => void;
    clear: () => void;
    setHighlight: (position: number) => void;
};
//# sourceMappingURL=use-markdown-stream.d.ts.map