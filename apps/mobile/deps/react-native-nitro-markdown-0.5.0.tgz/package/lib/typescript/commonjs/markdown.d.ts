import { type FC } from "react";
import { type FlatListProps, type StyleProp, type ViewStyle } from "react-native";
import { type MarkdownNode } from "./headless";
import type { ParserOptions } from "./Markdown.nitro";
import { type CustomRenderers, type LinkPressHandler } from "./MarkdownContext";
import { type PartialMarkdownTheme, type NodeStyleOverrides, type StylingStrategy } from "./theme";
export type AstTransform = (ast: MarkdownNode) => MarkdownNode;
export type MarkdownVirtualizationOptions = Pick<FlatListProps<MarkdownNode>, "initialNumToRender" | "maxToRenderPerBatch" | "windowSize" | "updateCellsBatchingPeriod" | "removeClippedSubviews">;
export type MarkdownPlugin = {
    /**
     * Optional plugin name used for diagnostics and debugging.
     */
    name?: string;
    /**
     * Optional plugin version metadata for diagnostics.
     */
    version?: string | number;
    /**
     * Optional text preprocessor executed before native parsing.
     * Should return a full markdown string.
     */
    beforeParse?: (markdown: string) => string;
    /**
     * Optional AST postprocessor executed after native parsing.
     */
    afterParse?: AstTransform;
};
export type MarkdownProps = {
    /**
     * The markdown string to parse and render.
     */
    children: string;
    /**
     * Parser options to enable GFM or Math support.
     */
    options?: ParserOptions;
    /**
     * Optional parser plugins for preprocessing and AST postprocessing.
     */
    plugins?: MarkdownPlugin[];
    /**
     * Optional pre-parsed AST.
     * When provided, native parse is skipped and this tree is rendered instead.
     */
    sourceAst?: MarkdownNode;
    /**
     * Optional transform applied after parsing and before rendering.
     * The transformed AST is also returned in `onParseComplete`.
     */
    astTransform?: AstTransform;
    /**
     * Callback fired when parsing begins.
     */
    onParsingInProgress?: () => void;
    /**
     * Callback fired when parsing completes.
     */
    onParseComplete?: (result: {
        raw: string;
        ast: MarkdownNode;
        text: string;
    }) => void;
    /**
     * Custom renderers for specific markdown node types.
     * Each renderer receives { node, children, Renderer } plus type-specific props.
     */
    renderers?: CustomRenderers;
    /**
     * Custom theme tokens to override default styles.
     */
    theme?: PartialMarkdownTheme;
    /**
     * Style overrides for specific node types.
     * Applied after internal styles, allowing fine-grained customization.
     * @example
     * ```tsx
     * <Markdown styles={{ heading: { color: 'red' }, code_block: { borderRadius: 0 } }}>
     *   {content}
     * </Markdown>
     * ```
     */
    styles?: NodeStyleOverrides;
    /**
     * Styling strategy for the component.
     * - "opinionated": Balanced defaults with spacing and neutral colors (default)
     * - "minimal": Bare minimum styling for a clean slate
     */
    stylingStrategy?: StylingStrategy;
    /**
     * Optional style for the container view.
     */
    style?: StyleProp<ViewStyle>;
    /**
     * Optional link press handler.
     * Return false to prevent the default openURL behavior.
     */
    onLinkPress?: LinkPressHandler;
    /**
     * Enables top-level block virtualization for very large markdown documents.
     * Best used when Markdown is the primary scroll container on screen.
     * - `true`: always virtualize when block threshold is met
     * - `"auto"`: virtualize only when threshold is met (recommended for large docs)
     * - `false`: disable virtualization (default)
     */
    virtualize?: boolean | "auto";
    /**
     * Minimum number of top-level blocks before virtualization is activated.
     * Helps avoid FlatList overhead on small documents.
     */
    virtualizationMinBlocks?: number;
    /**
     * Optional FlatList tuning for virtualization.
     */
    virtualization?: MarkdownVirtualizationOptions;
};
export declare const Markdown: FC<MarkdownProps>;
//# sourceMappingURL=markdown.d.ts.map