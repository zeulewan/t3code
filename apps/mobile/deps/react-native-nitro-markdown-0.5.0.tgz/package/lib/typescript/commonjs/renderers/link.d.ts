import { type FC, type ReactNode } from "react";
import { type TextStyle } from "react-native";
type LinkProps = {
    href: string;
    children: ReactNode;
    style?: TextStyle;
};
export declare const Link: FC<LinkProps>;
export {};
//# sourceMappingURL=link.d.ts.map