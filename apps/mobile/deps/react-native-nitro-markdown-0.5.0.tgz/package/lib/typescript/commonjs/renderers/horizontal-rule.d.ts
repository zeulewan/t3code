import { type FC } from "react";
import { type ViewStyle } from "react-native";
type HorizontalRuleProps = {
    style?: ViewStyle;
};
export declare const HorizontalRule: FC<HorizontalRuleProps>;
export {};
//# sourceMappingURL=horizontal-rule.d.ts.map