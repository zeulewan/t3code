import { type FC, type ReactNode } from "react";
import { type ViewStyle } from "react-native";
type ListProps = {
    ordered: boolean;
    start?: number;
    depth: number;
    children: ReactNode;
    style?: ViewStyle;
};
export declare const List: FC<ListProps>;
type ListItemProps = {
    children: ReactNode;
    index: number;
    ordered: boolean;
    start: number;
    style?: ViewStyle;
};
export declare const ListItem: FC<ListItemProps>;
type TaskListItemProps = {
    children: ReactNode;
    checked: boolean;
    style?: ViewStyle;
};
export declare const TaskListItem: FC<TaskListItemProps>;
export {};
//# sourceMappingURL=list.d.ts.map