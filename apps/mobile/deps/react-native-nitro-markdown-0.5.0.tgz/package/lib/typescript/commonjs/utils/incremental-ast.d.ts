import { type MarkdownNode } from "../headless";
import type { ParserOptions } from "../Markdown.nitro";
export type IncrementalAstInput = {
    allowIncremental?: boolean;
    nextText: string;
    options?: ParserOptions;
    previousAst: MarkdownNode;
    previousText: string;
};
export declare const getNextStreamAst: ({ allowIncremental, nextText, options, previousAst, previousText, }: IncrementalAstInput) => MarkdownNode;
export declare const parseMarkdownAst: (text: string, options?: ParserOptions) => MarkdownNode;
//# sourceMappingURL=incremental-ast.d.ts.map