import { type FC, type ReactNode } from "react";
import { type ViewStyle, type TextStyle } from "react-native";
import type { MarkdownNode } from "../headless";
type CodeBlockProps = {
    language?: string;
    content?: string;
    node?: MarkdownNode;
    style?: ViewStyle;
};
export declare const CodeBlock: FC<CodeBlockProps>;
type InlineCodeProps = {
    content?: string;
    node?: MarkdownNode;
    children?: ReactNode;
    style?: TextStyle;
};
export declare const InlineCode: FC<InlineCodeProps>;
export {};
//# sourceMappingURL=code.d.ts.map