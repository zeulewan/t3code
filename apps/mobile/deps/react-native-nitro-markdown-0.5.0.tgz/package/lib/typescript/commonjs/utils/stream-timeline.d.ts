export type TimestampEntry = {
    index: number;
    time: number;
};
export type TimestampTimeline = {
    entries: TimestampEntry[];
    monotonic: boolean;
};
export declare const createTimestampTimeline: (timestamps?: Record<number, number>) => TimestampTimeline;
export declare const resolveHighlightPosition: (timeline: TimestampTimeline, currentTimeMs: number) => number;
//# sourceMappingURL=stream-timeline.d.ts.map