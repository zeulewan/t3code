import { type TextStyle, type ViewStyle } from "react-native";
import type { MarkdownNode } from "./headless";
export type MarkdownTheme = {
    colors: {
        text: string | undefined;
        textMuted: string | undefined;
        heading: string | undefined;
        link: string | undefined;
        code: string | undefined;
        codeBackground: string | undefined;
        codeLanguage: string | undefined;
        blockquote: string | undefined;
        border: string | undefined;
        surface: string | undefined;
        surfaceLight: string | undefined;
        accent: string | undefined;
        tableBorder: string | undefined;
        tableHeader: string | undefined;
        tableHeaderText: string | undefined;
        tableRowEven: string | undefined;
        tableRowOdd: string | undefined;
    };
    spacing: {
        xs: number;
        s: number;
        m: number;
        l: number;
        xl: number;
    };
    fontSizes: {
        xs: number;
        s: number;
        m: number;
        l: number;
        xl: number;
        h1: number;
        h2: number;
        h3: number;
        h4: number;
        h5: number;
        h6: number;
    };
    fontFamilies: {
        regular: string | undefined;
        heading: string | undefined;
        mono: string | undefined;
    };
    headingWeight?: TextStyle["fontWeight"];
    borderRadius: {
        s: number;
        m: number;
        l: number;
    };
    showCodeLanguage: boolean;
};
export declare const defaultMarkdownTheme: MarkdownTheme;
export type PartialMarkdownTheme = {
    [K in keyof MarkdownTheme]?: K extends "showCodeLanguage" | "headingWeight" ? MarkdownTheme[K] : MarkdownTheme[K] extends object ? Partial<MarkdownTheme[K]> : MarkdownTheme[K];
};
export type NodeStyleOverrides = Partial<Record<MarkdownNode["type"], ViewStyle | TextStyle>>;
export type StylingStrategy = "opinionated" | "minimal";
export declare const minimalMarkdownTheme: MarkdownTheme;
export declare const mergeThemes: (base: MarkdownTheme, partial?: PartialMarkdownTheme) => MarkdownTheme;
//# sourceMappingURL=theme.d.ts.map