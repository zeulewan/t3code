import { type FC, type ComponentType } from "react";
import { type ViewStyle } from "react-native";
import type { NodeRendererProps } from "../MarkdownContext";
type ImageProps = {
    url: string;
    title?: string;
    alt?: string;
    Renderer?: ComponentType<NodeRendererProps>;
    style?: ViewStyle;
};
export declare const Image: FC<ImageProps>;
export {};
//# sourceMappingURL=image.d.ts.map