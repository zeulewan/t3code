import { type FC, type ReactNode } from "react";
import { type StyleProp, type ViewStyle } from "react-native";
type ParagraphProps = {
    children: ReactNode;
    inListItem?: boolean;
    style?: StyleProp<ViewStyle>;
};
export declare const Paragraph: FC<ParagraphProps>;
export {};
//# sourceMappingURL=paragraph.d.ts.map