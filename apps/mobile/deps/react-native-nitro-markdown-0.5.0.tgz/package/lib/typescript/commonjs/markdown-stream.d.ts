import { type FC } from "react";
import { type MarkdownProps } from "./markdown";
import type { MarkdownSession } from "./specs/MarkdownSession.nitro";
export type MarkdownStreamProps = {
    /**
     * The active MarkdownSession to stream content from.
     */
    session: MarkdownSession;
    /**
     * Throttle UI updates to avoid re-rendering on every token.
     * Defaults to 50ms, which keeps UI responsive while streaming.
     */
    updateIntervalMs?: number;
    /**
     * Update strategy for streaming renders.
     * - "interval": throttle to a fixed interval (default)
     * - "raf": update at most once per animation frame
     */
    updateStrategy?: "interval" | "raf";
    /**
     * Use React transitions for streaming updates.
     * Useful when you want to prioritize user interactions over stream renders.
     */
    useTransitionUpdates?: boolean;
    /**
     * Enable incremental AST updates for append-only streams.
     * Automatically falls back to full parse when updates are not safely mergeable.
     */
    incrementalParsing?: boolean;
} & Omit<MarkdownProps, "children" | "sourceAst">;
/**
 * A component that renders streaming Markdown from a MarkdownSession.
 * It efficiently subscribes to session updates to minimize parent re-renders.
 */
export declare const MarkdownStream: FC<MarkdownStreamProps>;
//# sourceMappingURL=markdown-stream.d.ts.map