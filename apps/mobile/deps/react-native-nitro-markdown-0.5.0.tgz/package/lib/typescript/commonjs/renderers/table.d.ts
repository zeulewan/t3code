import { type FC, type ComponentType } from "react";
import { type ViewStyle } from "react-native";
import { type MarkdownNode } from "../headless";
import { type NodeRendererProps } from "../MarkdownContext";
type TableRendererProps = {
    node: MarkdownNode;
    Renderer: ComponentType<NodeRendererProps>;
    style?: ViewStyle;
};
export declare const TableRenderer: FC<TableRendererProps>;
export {};
//# sourceMappingURL=table.d.ts.map