export declare const normalizeLinkHref: (href: string) => string | null;
export declare const getAllowedExternalHref: (href: string) => string | null;
//# sourceMappingURL=link-security.d.ts.map