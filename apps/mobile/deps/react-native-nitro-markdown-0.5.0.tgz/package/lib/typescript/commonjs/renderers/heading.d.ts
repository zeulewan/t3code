import { type FC, type ReactNode } from "react";
import { type TextStyle } from "react-native";
type HeadingProps = {
    level: number;
    children: ReactNode;
    style?: TextStyle;
};
export declare const Heading: FC<HeadingProps>;
export {};
//# sourceMappingURL=heading.d.ts.map