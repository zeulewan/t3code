import type { MarkdownSession as MarkdownSessionSpec } from "./specs/MarkdownSession.nitro";
export type MarkdownSession = MarkdownSessionSpec;
export declare function createMarkdownSession(): MarkdownSession;
//# sourceMappingURL=MarkdownSession.d.ts.map