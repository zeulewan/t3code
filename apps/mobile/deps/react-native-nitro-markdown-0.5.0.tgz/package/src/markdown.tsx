import {
  memo,
  useCallback,
  useEffect,
  useMemo,
  type FC,
  Fragment,
  type ReactElement,
  type ReactNode,
} from "react";
import {
  StyleSheet,
  View,
  Text,
  FlatList,
  Platform,
  type ListRenderItemInfo,
  type FlatListProps,
  type StyleProp,
  type ViewStyle,
} from "react-native";
import {
  parseMarkdown,
  parseMarkdownWithOptions,
  getFlattenedText,
  getTextContent,
  type MarkdownNode,
} from "./headless";
import type { ParserOptions } from "./Markdown.nitro";
import {
  MarkdownContext,
  useMarkdownContext,
  type CustomRenderers,
  type LinkPressHandler,
  type NodeRendererProps,
} from "./MarkdownContext";
import { Blockquote } from "./renderers/blockquote";
import { CodeBlock, InlineCode } from "./renderers/code";
import { Heading } from "./renderers/heading";
import { HorizontalRule } from "./renderers/horizontal-rule";
import { Image } from "./renderers/image";
import { Link } from "./renderers/link";
import { List, ListItem, TaskListItem } from "./renderers/list";
import { MathInline, MathBlock } from "./renderers/math";
import { Paragraph } from "./renderers/paragraph";
import { TableRenderer } from "./renderers/table";
import {
  defaultMarkdownTheme,
  minimalMarkdownTheme,
  mergeThemes,
  type MarkdownTheme,
  type PartialMarkdownTheme,
  type NodeStyleOverrides,
  type StylingStrategy,
} from "./theme";

const baseStylesCache = new WeakMap<MarkdownTheme, BaseStyles>();
const parseAstCache = new Map<string, MarkdownNode>();
const MAX_PARSE_CACHE_ENTRIES = 32;
const MAX_CACHEABLE_TEXT_LENGTH = 24_000;
const ANDROID_INLINE_MATH_SENTINEL_STYLE = {
  color: "transparent",
  fontSize: 1,
  lineHeight: 1,
  includeFontPadding: false as const,
};

export type AstTransform = (ast: MarkdownNode) => MarkdownNode;
export type MarkdownVirtualizationOptions = Pick<
  FlatListProps<MarkdownNode>,
  | "initialNumToRender"
  | "maxToRenderPerBatch"
  | "windowSize"
  | "updateCellsBatchingPeriod"
  | "removeClippedSubviews"
>;

export type MarkdownPlugin = {
  /**
   * Optional plugin name used for diagnostics and debugging.
   */
  name?: string;
  /**
   * Optional plugin version metadata for diagnostics.
   */
  version?: string | number;
  /**
   * Optional text preprocessor executed before native parsing.
   * Should return a full markdown string.
   */
  beforeParse?: (markdown: string) => string;
  /**
   * Optional AST postprocessor executed after native parsing.
   */
  afterParse?: AstTransform;
};

const isMarkdownNode = (value: unknown): value is MarkdownNode => {
  if (typeof value !== "object" || value === null) return false;
  return typeof Reflect.get(value, "type") === "string";
};

const warnInDev = (message: string, error?: unknown): void => {
  if (typeof __DEV__ === "undefined" || !__DEV__) return;

  const runtimeConsole = Reflect.get(globalThis, "console");
  if (
    typeof runtimeConsole === "object" &&
    runtimeConsole !== null &&
    "warn" in runtimeConsole &&
    typeof runtimeConsole.warn === "function"
  ) {
    runtimeConsole.warn(message, error);
  }
};

const cloneMarkdownNode = (node: MarkdownNode): MarkdownNode => {
  return {
    ...node,
    children: node.children?.map(cloneMarkdownNode),
  };
};

const getParserOptionsKey = (options?: ParserOptions): string => {
  if (!options) return "gfm:default|math:default";

  const gfm = options.gfm === undefined ? "default" : options.gfm ? "1" : "0";
  const math =
    options.math === undefined ? "default" : options.math ? "1" : "0";
  return `gfm:${gfm}|math:${math}`;
};

const normalizeParserOptions = (
  options?: ParserOptions,
): ParserOptions | undefined => {
  if (!options) return undefined;

  const gfm = options.gfm;
  const math = options.math;

  if (gfm === undefined && math === undefined) {
    return undefined;
  }

  return {
    gfm,
    math,
  };
};

const parseWithNativeParser = (
  text: string,
  options?: ParserOptions,
): MarkdownNode => {
  if (options) {
    return parseMarkdownWithOptions(text, options);
  }
  return parseMarkdown(text);
};

const getCachedParsedAst = (
  text: string,
  options?: ParserOptions,
): MarkdownNode => {
  if (text.length > MAX_CACHEABLE_TEXT_LENGTH) {
    return parseWithNativeParser(text, options);
  }

  const cacheKey = `${getParserOptionsKey(options)}|${text}`;
  const cachedNode = parseAstCache.get(cacheKey);
  if (cachedNode) {
    parseAstCache.delete(cacheKey);
    parseAstCache.set(cacheKey, cachedNode);
    return cloneMarkdownNode(cachedNode);
  }

  const parsedNode = parseWithNativeParser(text, options);
  parseAstCache.set(cacheKey, parsedNode);
  if (parseAstCache.size > MAX_PARSE_CACHE_ENTRIES) {
    const oldestCacheKey = parseAstCache.keys().next().value;
    if (typeof oldestCacheKey === "string") {
      parseAstCache.delete(oldestCacheKey);
    }
  }

  return cloneMarkdownNode(parsedNode);
};

const applyBeforeParsePlugins = (
  markdown: string,
  plugins?: MarkdownPlugin[],
): string => {
  if (!plugins || plugins.length === 0) {
    return markdown;
  }

  let nextMarkdown = markdown;
  for (const plugin of plugins) {
    if (!plugin.beforeParse) continue;

    try {
      const transformed = plugin.beforeParse(nextMarkdown);
      if (typeof transformed === "string") {
        nextMarkdown = transformed;
      }
    } catch (error) {
      const pluginLabel = plugin.name ? ` (${plugin.name})` : "";
      warnInDev(
        `[react-native-nitro-markdown] plugin beforeParse${pluginLabel} threw; using previous markdown.`,
        error,
      );
    }
  }

  return nextMarkdown;
};

const applyAfterParsePlugins = (
  ast: MarkdownNode,
  plugins?: MarkdownPlugin[],
): MarkdownNode => {
  if (!plugins || plugins.length === 0) {
    return ast;
  }

  let nextAst = ast;
  for (const plugin of plugins) {
    if (!plugin.afterParse) continue;

    try {
      const transformed = plugin.afterParse(nextAst);
      if (isMarkdownNode(transformed)) {
        nextAst = transformed;
      }
    } catch (error) {
      const pluginLabel = plugin.name ? ` (${plugin.name})` : "";
      warnInDev(
        `[react-native-nitro-markdown] plugin afterParse${pluginLabel} threw; using previous AST.`,
        error,
      );
    }
  }

  return nextAst;
};

export type MarkdownProps = {
  /**
   * The markdown string to parse and render.
   */
  children: string;
  /**
   * Parser options to enable GFM or Math support.
   */
  options?: ParserOptions;
  /**
   * Optional parser plugins for preprocessing and AST postprocessing.
   */
  plugins?: MarkdownPlugin[];
  /**
   * Optional pre-parsed AST.
   * When provided, native parse is skipped and this tree is rendered instead.
   */
  sourceAst?: MarkdownNode;
  /**
   * Optional transform applied after parsing and before rendering.
   * The transformed AST is also returned in `onParseComplete`.
   */
  astTransform?: AstTransform;
  /**
   * Callback fired when parsing begins.
   */
  onParsingInProgress?: () => void;
  /**
   * Callback fired when parsing completes.
   */
  onParseComplete?: (result: {
    raw: string;
    ast: MarkdownNode;
    text: string;
  }) => void;
  /**
   * Custom renderers for specific markdown node types.
   * Each renderer receives { node, children, Renderer } plus type-specific props.
   */
  renderers?: CustomRenderers;
  /**
   * Custom theme tokens to override default styles.
   */
  theme?: PartialMarkdownTheme;
  /**
   * Style overrides for specific node types.
   * Applied after internal styles, allowing fine-grained customization.
   * @example
   * ```tsx
   * <Markdown styles={{ heading: { color: 'red' }, code_block: { borderRadius: 0 } }}>
   *   {content}
   * </Markdown>
   * ```
   */
  styles?: NodeStyleOverrides;
  /**
   * Styling strategy for the component.
   * - "opinionated": Balanced defaults with spacing and neutral colors (default)
   * - "minimal": Bare minimum styling for a clean slate
   */
  stylingStrategy?: StylingStrategy;
  /**
   * Optional style for the container view.
   */
  style?: StyleProp<ViewStyle>;
  /**
   * Optional link press handler.
   * Return false to prevent the default openURL behavior.
   */
  onLinkPress?: LinkPressHandler;
  /**
   * Enables top-level block virtualization for very large markdown documents.
   * Best used when Markdown is the primary scroll container on screen.
   * - `true`: always virtualize when block threshold is met
   * - `"auto"`: virtualize only when threshold is met (recommended for large docs)
   * - `false`: disable virtualization (default)
   */
  virtualize?: boolean | "auto";
  /**
   * Minimum number of top-level blocks before virtualization is activated.
   * Helps avoid FlatList overhead on small documents.
   */
  virtualizationMinBlocks?: number;
  /**
   * Optional FlatList tuning for virtualization.
   */
  virtualization?: MarkdownVirtualizationOptions;
};

export const Markdown: FC<MarkdownProps> = ({
  children,
  options,
  plugins,
  sourceAst,
  astTransform,
  renderers = {},
  theme: userTheme,
  styles: nodeStyles,
  stylingStrategy = "opinionated",
  style,
  onParsingInProgress,
  onParseComplete,
  onLinkPress,
  virtualize = false,
  virtualizationMinBlocks = 40,
  virtualization,
}) => {
  const parserOptionGfm = options?.gfm;
  const parserOptionMath = options?.math;

  const parseResult = useMemo(() => {
    try {
      const markdownToParse = applyBeforeParsePlugins(children, plugins);
      const parserOptions = normalizeParserOptions({
        gfm: parserOptionGfm,
        math: parserOptionMath,
      });
      let parsedAst = sourceAst
        ? cloneMarkdownNode(sourceAst)
        : getCachedParsedAst(markdownToParse, parserOptions);
      parsedAst = applyAfterParsePlugins(parsedAst, plugins);

      let ast = parsedAst;
      if (astTransform) {
        try {
          const nextAst = astTransform(parsedAst);
          if (isMarkdownNode(nextAst)) {
            ast = nextAst;
          }
        } catch (error) {
          warnInDev(
            "[react-native-nitro-markdown] astTransform threw; falling back to parsed AST.",
            error,
          );
          ast = parsedAst;
        }
      }

      return {
        ast,
      };
    } catch {
      return {
        ast: null,
      };
    }
  }, [
    children,
    parserOptionGfm,
    parserOptionMath,
    plugins,
    sourceAst,
    astTransform,
  ]);

  useEffect(() => {
    onParsingInProgress?.();
  }, [
    children,
    parserOptionGfm,
    parserOptionMath,
    plugins,
    onParsingInProgress,
  ]);

  useEffect(() => {
    if (!parseResult.ast || !onParseComplete) return;

    onParseComplete({
      raw: children,
      ast: parseResult.ast,
      text: getFlattenedText(parseResult.ast),
    });
  }, [children, onParseComplete, parseResult.ast]);

  const theme = useMemo(() => {
    const base =
      stylingStrategy === "minimal"
        ? minimalMarkdownTheme
        : defaultMarkdownTheme;
    return mergeThemes(base, userTheme);
  }, [userTheme, stylingStrategy]);

  const baseStyles = getBaseStyles(theme);
  const contextValue = useMemo(
    () => ({
      renderers,
      theme,
      styles: nodeStyles,
      stylingStrategy,
      onLinkPress,
    }),
    [renderers, theme, nodeStyles, stylingStrategy, onLinkPress],
  );

  const topLevelBlocks =
    parseResult.ast?.type === "document"
      ? (parseResult.ast.children ?? [])
      : parseResult.ast
        ? [parseResult.ast]
        : [];
  const shouldVirtualizeBySetting =
    virtualize === true ||
    (virtualize === "auto" && topLevelBlocks.length >= virtualizationMinBlocks);
  const shouldVirtualize =
    parseResult.ast !== null && shouldVirtualizeBySetting;

  const keyExtractor = useCallback((node: MarkdownNode, index: number) => {
    const beg = typeof node.beg === "number" ? node.beg : index;
    const end = typeof node.end === "number" ? node.end : index;
    return `${node.type}:${beg}:${end}:${index}`;
  }, []);

  const renderVirtualizedItem = useCallback(
    ({ item, index }: ListRenderItemInfo<MarkdownNode>): ReactElement => (
      <NodeRenderer
        node={item}
        depth={0}
        inListItem={false}
        parentType="document"
        isLastChildInParent={index === topLevelBlocks.length - 1}
      />
    ),
    [topLevelBlocks.length],
  );

  if (!parseResult.ast) {
    return (
      <View style={[baseStyles.container, style]}>
        <Text style={baseStyles.errorText}>Error parsing markdown</Text>
      </View>
    );
  }

  return (
    <MarkdownContext.Provider value={contextValue}>
      <View style={[baseStyles.container, style]}>
        {shouldVirtualize ? (
          <FlatList
            data={topLevelBlocks}
            renderItem={renderVirtualizedItem}
            keyExtractor={keyExtractor}
            style={baseStyles.virtualizedList}
            initialNumToRender={virtualization?.initialNumToRender ?? 12}
            maxToRenderPerBatch={virtualization?.maxToRenderPerBatch ?? 12}
            windowSize={virtualization?.windowSize ?? 10}
            updateCellsBatchingPeriod={
              virtualization?.updateCellsBatchingPeriod ?? 16
            }
            removeClippedSubviews={
              virtualization?.removeClippedSubviews ?? true
            }
            showsVerticalScrollIndicator={false}
          />
        ) : (
          <NodeRenderer node={parseResult.ast} depth={0} inListItem={false} />
        )}
      </View>
    </MarkdownContext.Provider>
  );
};

const isInline = (type: MarkdownNode["type"]): boolean => {
  return (
    type === "text" ||
    type === "bold" ||
    type === "italic" ||
    type === "strikethrough" ||
    type === "link" ||
    type === "code_inline" ||
    type === "soft_break" ||
    type === "line_break" ||
    type === "html_inline" ||
    type === "math_inline"
  );
};

const removeTrailingInlineLineBreaks = (
  inlineGroup: MarkdownNode[],
): boolean => {
  let removed = false;
  while (inlineGroup[inlineGroup.length - 1]?.type === "line_break") {
    inlineGroup.pop();
    removed = true;
  }
  return removed;
};

const trimMarginBottom = <T extends object | undefined>(
  style: T,
  shouldTrim: boolean,
): T => {
  if (!shouldTrim) return style;
  return {
    ...(style ?? {}),
    marginBottom: 0,
  } as T;
};

type InternalNodeRendererProps = NodeRendererProps & {
  parentType?: MarkdownNode["type"];
  isLastChildInParent?: boolean;
};

const NodeRendererComponent: FC<InternalNodeRendererProps> = ({
  node,
  depth,
  inListItem,
  parentIsText = false,
  parentType,
  isLastChildInParent = false,
}) => {
  const { renderers, theme, styles: nodeStyles } = useMarkdownContext();
  const baseStyles = getBaseStyles(theme);

  const renderChildren = (
    children?: MarkdownNode[],
    childInListItem = false,
    childParentIsText = false,
  ): ReactNode => {
    if (!children || children.length === 0) return null;

    const elements: ReactNode[] = [];
    let currentInlineGroup: MarkdownNode[] = [];

    const flushInlineGroup = () => {
      if (currentInlineGroup.length > 0) {
        const Wrapper = childParentIsText ? Fragment : Text;
        const wrapperProps = childParentIsText
          ? {}
          : { style: baseStyles.text };

        elements.push(
          <Wrapper key={`inline-group-${elements.length}`} {...wrapperProps}>
            {currentInlineGroup.map((n, idx) => (
              <NodeRenderer
                key={`${n.type}-${idx}`}
                node={n}
                depth={depth + 1}
                inListItem={childInListItem}
                parentIsText={true}
              />
            ))}
            {currentInlineGroup.length === 1 &&
              currentInlineGroup[0].type === "math_inline" &&
              " "}
            {Platform.OS === "android" &&
              currentInlineGroup.length > 1 &&
              currentInlineGroup[currentInlineGroup.length - 1]?.type ===
                "math_inline" && (
              // Android can misplace terminal inline attachments in Text.
              // Keep a hidden trailing visible glyph after terminal math.
              <Text
                style={ANDROID_INLINE_MATH_SENTINEL_STYLE}
                importantForAccessibility="no"
              >
                {"a"}
              </Text>
            )}
          </Wrapper>,
        );
        currentInlineGroup = [];
      }
    };

    children.forEach((child, index) => {
      if (isInline(child.type)) {
        currentInlineGroup.push(child);
      } else {
        const needsInlineToBlockWrapBreak =
          child.type === "math_block" &&
          removeTrailingInlineLineBreaks(currentInlineGroup);
        flushInlineGroup();
        if (needsInlineToBlockWrapBreak && !childParentIsText) {
          elements.push(
            <View
              key={`inline-wrap-break-${elements.length}`}
              style={baseStyles.inlineWrapBreak}
            />,
          );
        }
        elements.push(
          <NodeRenderer
            key={`${child.type}-${index}`}
            node={child}
            depth={depth + 1}
            inListItem={childInListItem}
            parentIsText={childParentIsText}
            parentType={node.type}
            isLastChildInParent={index === children.length - 1}
          />,
        );
      }
    });

    flushInlineGroup();
    return elements;
  };

  const customRenderer = renderers[node.type];
  if (customRenderer) {
    const childrenRendered = renderChildren(
      node.children,
      inListItem,
      parentIsText,
    );

    const baseProps = {
      node,
      children: childrenRendered,
      Renderer: NodeRenderer,
    };

    const enhancedProps = {
      ...baseProps,
      ...(node.type === "heading" && {
        level: (node.level ?? 1) as 1 | 2 | 3 | 4 | 5 | 6,
      }),
      ...(node.type === "link" && { href: node.href ?? "", title: node.title }),
      ...(node.type === "image" && {
        url: node.href ?? "",
        alt: node.alt,
        title: node.title,
      }),
      ...(node.type === "code_block" && {
        content: getTextContent(node),
        language: node.language,
      }),
      ...(node.type === "code_inline" && { content: node.content ?? "" }),
      ...(node.type === "list" && {
        ordered: node.ordered ?? false,
        start: node.start,
      }),
      ...(node.type === "task_list_item" && { checked: node.checked ?? false }),
      ...((node.type === "math_inline" || node.type === "math_block") && { content: getTextContent(node) }),
    };

    const result = customRenderer(enhancedProps);
    if (result !== undefined) {
      return result as ReactElement | null;
    }
  }

  const isLastRootChild =
    !inListItem && parentType === "document" && isLastChildInParent;
  const nodeStyleOverride = trimMarginBottom(
    nodeStyles?.[node.type],
    isLastRootChild ||
      (node.type === "task_list_item" &&
        parentType === "list" &&
        isLastChildInParent),
  );

  switch (node.type) {
    case "document":
      return (
        <View style={[baseStyles.document, nodeStyleOverride]}>
          {renderChildren(node.children, false, false)}
        </View>
      );

    case "heading":
      return (
        <Heading level={node.level ?? 1} style={nodeStyleOverride}>
          {renderChildren(node.children, inListItem, true)}
        </Heading>
      );

    case "paragraph":
      return (
        <Paragraph inListItem={inListItem} style={nodeStyleOverride}>
          {renderChildren(node.children, inListItem, false)}
        </Paragraph>
      );

    case "text":
      if (parentIsText) {
        return <Text>{node.content}</Text>;
      }
      return (
        <Text style={[baseStyles.text, nodeStyleOverride]}>{node.content}</Text>
      );

    case "bold":
      return (
        <Text style={[baseStyles.bold, nodeStyleOverride]}>
          {renderChildren(node.children, inListItem, true)}
        </Text>
      );

    case "italic":
      return (
        <Text style={[baseStyles.italic, nodeStyleOverride]}>
          {renderChildren(node.children, inListItem, true)}
        </Text>
      );

    case "strikethrough":
      return (
        <Text style={[baseStyles.strikethrough, nodeStyleOverride]}>
          {renderChildren(node.children, inListItem, true)}
        </Text>
      );

    case "link":
      return (
        <Link href={node.href ?? ""} style={nodeStyleOverride}>
          {renderChildren(node.children, inListItem, true)}
        </Link>
      );

    case "image":
      return (
        <Image
          url={node.href ?? ""}
          title={node.title}
          alt={node.alt}
          Renderer={NodeRenderer}
          style={nodeStyleOverride}
        />
      );

    case "code_inline":
      return <InlineCode style={nodeStyleOverride}>{node.content}</InlineCode>;

    case "code_block":
      return (
        <CodeBlock
          language={node.language}
          content={getTextContent(node)}
          style={nodeStyleOverride}
        />
      );

    case "blockquote":
      return (
        <Blockquote style={nodeStyleOverride}>
          {renderChildren(node.children, inListItem, false)}
        </Blockquote>
      );

    case "horizontal_rule":
      return <HorizontalRule style={nodeStyleOverride} />;

    case "line_break":
      return <Text>{"\n"}</Text>;

    case "soft_break":
      return <Text> </Text>;

    case "math_inline": {
      let mathContent = getTextContent(node);
      if (!mathContent) return null;
      mathContent = mathContent.replace(/^\$+|\$+$/g, "").trim();
      return <MathInline content={mathContent} style={nodeStyleOverride} />;
    }

    case "math_block":
      return (
        <MathBlock content={getTextContent(node)} style={nodeStyleOverride} />
      );

    case "list":
      return (
        <List
          ordered={node.ordered ?? false}
          start={node.start}
          depth={depth}
          style={nodeStyleOverride}
        >
          {node.children?.map((child, index) => {
            if (child.type === "task_list_item") {
              return (
                <NodeRenderer
                  key={index}
                  node={child}
                  depth={depth + 1}
                  inListItem={true}
                  parentIsText={false}
                  parentType={node.type}
                  isLastChildInParent={index === (node.children?.length ?? 0) - 1}
                />
              );
            }
            return (
              <ListItem
                key={index}
                index={index}
                ordered={node.ordered ?? false}
                start={node.start ?? 1}
                style={
                  index === (node.children?.length ?? 0) - 1
                    ? { marginBottom: 0 }
                    : undefined
                }
              >
                <NodeRenderer
                  node={child}
                  depth={depth + 1}
                  inListItem={true}
                  parentIsText={false}
                />
              </ListItem>
            );
          })}
        </List>
      );

    case "list_item":
      return <>{renderChildren(node.children, true, false)}</>;

    case "task_list_item":
      return (
        <TaskListItem checked={node.checked ?? false} style={nodeStyleOverride}>
          {renderChildren(node.children, true, false)}
        </TaskListItem>
      );

    case "table":
      return (
        <TableRenderer
          node={node}
          Renderer={NodeRenderer}
          style={nodeStyleOverride}
        />
      );

    case "table_head":
    case "table_body":
    case "table_row":
    case "table_cell":
      return null;

    default:
      return null;
  }
};

const NodeRenderer = memo(NodeRendererComponent, (previousProps, nextProps) => {
  return (
    previousProps.node === nextProps.node &&
    previousProps.depth === nextProps.depth &&
    previousProps.inListItem === nextProps.inListItem &&
    previousProps.parentIsText === nextProps.parentIsText &&
    previousProps.parentType === nextProps.parentType &&
    previousProps.isLastChildInParent === nextProps.isLastChildInParent
  );
}) as FC<InternalNodeRendererProps>;

type BaseStyles = ReturnType<typeof createBaseStyles>;

const getBaseStyles = (theme: MarkdownTheme): BaseStyles => {
  const cached = baseStylesCache.get(theme);
  if (cached) return cached;

  const created = createBaseStyles(theme);
  baseStylesCache.set(theme, created);
  return created;
};

const createBaseStyles = (theme: MarkdownTheme) =>
  StyleSheet.create({
    container: {
      flex: 1,
    },
    virtualizedList: {
      flex: 1,
    },
    document: {
      flex: 1,
    },
    errorText: {
      color: "#f87171",
      fontSize: 14,
      fontFamily: theme.fontFamilies.mono ?? "monospace",
      ...(Platform.OS === "android" && { includeFontPadding: false }),
    },
    text: {
      color: theme.colors.text,
      fontSize: theme.fontSizes.m,
      lineHeight: theme.fontSizes.m * 1.6,
      fontFamily: theme.fontFamilies.regular,
      ...(Platform.OS === "android" && { includeFontPadding: false }),
    },
    bold: {
      fontWeight: "700",
      ...(Platform.OS === "android" && { includeFontPadding: false }),
    },
    italic: {
      fontStyle: "italic",
      ...(Platform.OS === "android" && { includeFontPadding: false }),
    },
    strikethrough: {
      textDecorationLine: "line-through",
      ...(Platform.OS === "android" && { includeFontPadding: false }),
    },
    inlineWrapBreak: {
      flexBasis: "100%",
      height: 0,
    },
  });
